#include <iostream>
using namespace std;

int main() {
    int x;
    while (cin >> x) {          // نقرا لحد ما يخلص الإدخال
        if (x == 1999) {
            cout << "Correct" << endl;
            break;              // نوقف البرنامج
        } else {
            cout << "Wrong" << endl;
        }
    }
    return 0;
}
