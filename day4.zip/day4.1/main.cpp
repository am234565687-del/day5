#include <iostream>

using namespace std;

int main()
{
  /*  int x;
    cin>>x;
    for(int i=1; i<=x; i++){
      cout<<i<<endl;
    }
*/
int N, post=0, negt=0, even=0, odd=0;
cin>>N;
for(int i= -N;i<=N;i++){
    if(i%2==0)
        even++;
    else
        odd++;
    if(i>0)
        post++;
    else if(i<0)
        negt++;
}
cout<< "even: "<<even<<endl;
cout<< "odd: "<<odd<<endl;
cout<< "post: "<<post<<endl;
cout<< "negt: "<<negt<<endl;

    return 0;
}


