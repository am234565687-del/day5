#include <iostream>
using namespace std;
#include <cmath>

int main() {
    /*int n;
    cout << "enter the num: ";
    cin >> n;

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= i; j++) {
            cout << "*";
        }
        cout << endl;
    }
*/


    int n;
    cout<<"please enter your no"<<endl;
    cin >> n;

    cout<<"please enter your numbers"<<endl;
    int arr[n];
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int mx = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > mx)
            mx = arr[i];
            // mx = max(mx, arr[i]);
    }

    cout <<"max number is"<<mx << endl;

    return 0;
}



